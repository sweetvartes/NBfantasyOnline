# Albedo Template for Bootstrap 4
Albedo is a Free HTML Template Powered With Bootstrap 4

# Live Demo
Here is a link for see the live demo.
* [Demo Link](http://florent-vandroy.fr/projets/albedo/)

# Screenshot

![](capture.png)

# Getting Started
To use this templates, you only need to extract the files and open the index.html

# Build with
* [BootStrap](https://getbootstrap.com/) - BootStrap 4 

# Authors
* [Linkedin](https://www.linkedin.com/in/florent-v-2a9b77a2) - Florent Vandroy (Developer)
* [Dribble](https://dribbble.com/shots/3116578-Albedo-Free-Personal-Onepager-PSD-Template) - Themefire (Designer)

# Problems
If you have a problem with this template, contact me.

# Contact
* florentvandroy@gmail.com
