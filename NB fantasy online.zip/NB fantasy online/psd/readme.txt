Albedo - Free Personal Onepager PSD Template.

Fonts Used:
Work Sans https://fonts.google.com/specimen/Work+Sans
Montserrat https://www.google.com/fonts/specimen/Montserrat
Leckerli One https://fonts.google.com/specimen/Leckerli+One
Cambay https://fonts.google.com/specimen/Cambay

Icons Used: http://www.flaticon.com/
Free Photo Used: https://pixabay.com/

------------------------

You can download full version Albedo - Personal Onepager PSD Template (15 psd files) on Envato Elements:
https://elements.envato.com/items/type/graphic-templates/albedo-personal-onepager-psd-template-5A7KP6

Also you can buy Albedo - Universal & Multipurpose Soft Material PSD Template (180 psd files) on ThemeForest only for $18.
https://themeforest.net/item/albedo-universal-multipurpose-soft-material-psd-template/18342218

------------------------

Thank you for the attention and have a nice day ;)
Don't forget to provide link on my Dribbble or Envato profile.

https://dribbble.com/themefire
https://elements.envato.com/user/themefire
https://themeforest.net/user/themefire/portfolio

Regards, 
Dmitry (themefire).